/**
 * Created by Administrator on 2017/3/7.
 */
var aNum = new Array;
function stockMsg(num){

    var oDiv = document.getElementById('showMsg');
    var oScript = document.createElement('script');
    oScript.src = 'http://api.money.126.net/data/feed/' + num + '?callback=refreshPrice';
    oDiv.appendChild(oScript);
    aNum[0] = num;
}
function refreshPrice(data){
    var oDiv = document.getElementById('showMsg');
    oDiv.innerHTML = '股票名称：'+ data[aNum[0]].name + '最高价格：' + data[aNum[0]].high;
    console.log( data);
}